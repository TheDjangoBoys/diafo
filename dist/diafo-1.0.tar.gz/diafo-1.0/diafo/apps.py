from django.apps import AppConfig


class DiafoConfig(AppConfig):
    name = 'diafo'
